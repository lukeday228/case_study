# case_study

# R Scripts
Lake Waco Bathymetry.R contains the completed functional R script that has been cleaned up manually.  This should be used for best functionality.  
  
GPT Method.R contains more iterations of code from ChatGPT, along with some experimental code chunks.  This is included to show the process and iterations.

# .gpx files
Export5323.gpx is the only GPx file used in Lake Waco Bathymetry.R  
  
gecho.gpx and Export5323.gpx are both used in GPT Method.R   

# txt files
Main ChatGPT Thread.txt shows the primary conversation that developed the GPT Method.R script  
  
Random Requests.txt shows miscellaneous requests made to Chat GPT that assisted with the script development, but were not necessarily part of the main workflow development
